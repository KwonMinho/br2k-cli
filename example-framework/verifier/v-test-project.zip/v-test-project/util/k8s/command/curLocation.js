const Spray = require('robust-express-spray');

const spray = new Spray();
spray.getLocations();
