module.exports = {
    URL: "ldap://127.0.0.1:389",
    ADMIN_DN: "cn=admin,dc=verifier,dc=com",
    ROOT_DN: "dc=verifier,dc=com",
    PASSWORD: "pslab",
};
  