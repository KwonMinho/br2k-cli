const util_path = `${__dirname}/utils/`;
const cors = require('cors');

const LDAPClient = require(util_path+'ldap_client');
const ldapClient = new LDAPClient();

const DIDClient = require(util_path+'did_client/index');
const DIDCfg = require(util_path+'did_cfg');
const didCfg = new DIDCfg();
const didClient = new DIDClient({
    network: didCfg.getNetwork(),
    regABI: didCfg.getDidABI(),
    regAddr: didCfg.getDidAddr()
});

const config = {
  'service-registry': {
     id: 'verifier',
     endpoint: 'ws://203.250.77.150:8546',
     account: '0x2ff21a68a27137fa13a20e72066e9a2c8fe339bd',
     password: '1234',
     abi_path: `${__dirname}/config/ServiceRegistry.json`
   },
  'webpack-config': '',
  'debug-mode': true
};
const app = require('replication-app')(config);
app.use(cors());


//type, did
app.replicateReq('POST', '/service', async(req,res)=>{
    console.log(req.body)
	const {pubKeyID, signature, did, scvType, sigData} = {
        pubKeyID: `${req.body.did}#${req.body.keyid}`,
        signature: req.body.signature,
        did: req.body.did,
        scvType: req.body.scvType,
        sigData: req.body.sigData
    };

    // const auth = await didClient.didAuth(did, pubKeyID, signature, sigData);
    // const isValid = auth[0];
    // const resultMsg = auth[1];
    const isValid = true;
    if(!isValid) res.send(resultMsg);
    else{
        ldapClient.addService({did: did, ou: scvType});
        res.send("Success Enroll to service");
    }
});


app.replicateReq('POST', '/user', async(req,res)=>{
	const {uDID, pubKeyID, signature, sn ,cn, privilege, sigData, sDID} = {
        uDID: req.body.did,
        pubKeyID: `${req.body.did}#${req.body.keyid}`,
        signature: req.body.signature,
        sn: req.body.sn,
        cn: req.body.cn,
        privilege: req.body.privilege,
        sigData: req.body.sigData,
        sDID: req.body.sDid
    };

    // 1. ldap에 해당 서비스와 유저가 있는지 확인
    const event = ldapClient.searchUser(sDID, uDID);

    event.on('search', async (results)=>{
        //2. 서비스가 있어야하고 유저가 없어야함.
        const storageInfo  = results[0];
        const userInfo = results[1];

        const storageDN = storageInfo.dn;


        //3. 서비스가 없다면 return or 유저가 있다면 리턴
        if(storageInfo == null || userInfo != null) {
            res.send('Not exist service! or Already user!');
            return;
        }

        //4. 해당 유저 did auth를 통한 신원검증
        // const auth = await didClient.didAuth(did, pubKeyID, signature, sigData);
        // const isValid = auth[0];
        // const resultMsg = auth[1];

        
        const isValid = true;
        if(!isValid){
            res.send(resultMsg);
        }else{
             //저장
            ldapClient.addUser({did: uDID, sn: sn, cn: cn, privilege: privilege}, storageDN);
            res.send("Success Enroll");
        }
    });
});

app.req('GET','/user',async(req,res)=>{
        const {uDID, pubKeyID, signature, fileName, fileSize, fileType, fileDesc, contentType, filesMetaHash, sDID} = 
        {
            uDID: req.query.did,
            pubKeyID: `${req.query.did}#${req.query.keyid}`,
            signature: req.query.signature,
            fileName: req.query.contentName,
            fileType: req.query.fileType,
            fileSize: req.query.contentSize,
            fileDesc: req.query.contentDesc,
            contentType: req.query.contentType,
            filesMetaHash: req.query.contentsMetaHash,
            sDID: req.query.storageDID
        };

        const event = ldapClient.searchUser(sDID, uDID);
        event.on('search', async (results)=>{
            const storageInfo  = results[0];
            const userInfo = results[1];

            if(storageInfo == null) {
                res.send('Not exist service!');
                return;
            }
            if(userInfo == null){
                res.send('Not exist user!');
                return;
            }
            const authResults = await didClient.didAuth(uDID, pubKeyID, signature, filesMetaHash);
            const isValid = authResults[0];
            const resultMsg = authResults[1];

            //const isValid = true
            if(!isValid){
                res.send(resultMsg);
            }else{
                const serviceInfo = {did: sDID, name: 'serviceName', endPoint: 'http://203.250.77.140:8000/accesstoken'}; //modify!
                const userInfo =  {
                    did: uDID, 
                    privilege: 'all', 
                    keyID: pubKeyID, 
                    sig: signature, 
                    fileName: fileName,
                    fileType: fileType,
                    fileSize: fileSize,
                    fileDesc: fileDesc,
                    contentType: contentType,
                    filesMetaHash: filesMetaHash
                }; //modify!
                const createdTime = new Date()+" ";

                const pKeyObj = didCfg.getRandomPrivatekey(); //pKeyObj: {id:"pubKeyID", type: "", value: "privateKey" }
                const vDid = didCfg.getDid();
                const vEndpoint = didCfg.getEndpoint();
                const credentialData = createdTime.toString()+JSON.stringify(serviceInfo)+JSON.stringify(userInfo);

                const credentialSig = didClient.sign(credentialData, pKeyObj.type, pKeyObj.value );
                const verifierInfo  = { did: vDid, keyID: pKeyObj.id, sig: credentialSig, endpoint: vEndpoint };

                res.send({
                    createdTime: createdTime,
                    service: serviceInfo,
                    user: userInfo,
                    verifier: verifierInfo
                });
            }            
        });
})

app.listen(3000,()=>{
  console.log('service replication has started on port 3000')
})
